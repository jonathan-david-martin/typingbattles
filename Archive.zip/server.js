/**
 * Created by jonathanmar on 10/17/16.
 */

//initialize app to be a function handler you can supply to
    //an HTTP server
var app = require('express')();
var counter = 0;

var hostname = '0.0.0.0';
var port = process.env.PORT || 3000;

var clients = [];
//the app object which serves as a function handler is
//supplied to an http server
var server = require('http').Server(app);
//var http = require('http').Server(app);


//initialize a new instance of socket.io by
//passing in the http server
//the listen on the connection event
//for incoming sockets
var io = require('socket.io')(server);



app.get('/', function(req, res){
    res.sendfile('index.html');
});

io.on('connection', function(socket){
    console.log('a user connected');
});
//not sure why there are 2 of these


io.on('connection', function(socket){
    socket.on('chat message', function(msg){
        //i think because this is coming from the server it goes to everyone
        io.emit('chat message', msg);
        if (msg == 'right'){
            console.log("someone typed right");
            io.emit('right', "someone typed right");
        }
        if (msg == 'left'){
            console.log("someone typed left");
            io.emit('left', "someone typed left");
        }
    });

    socket.on('join',function(data){

        counter += 1;
        console.log(data + counter);
        socket.emit('your number',counter);
        //io.emit()
    });
    //io.clients(function(error, clients){
    //    if (error) throw error;
    //    console.log(clients); // => [6em3d4TJP8Et9EMNAAAA, G5p55dHhGgUnLUctAAAB]
    //});
});

var port = process.env.PORT || 8120;

//this is a route handler and defines
//what happens when someone reaches the home page
//req is the request
app.get('/', function(req, res){
    res.send('<h1>Hello world</h1>');
});

server.listen(port, hostname, function(){
    console.log('listening on ' + hostname + ':' + port);
});
